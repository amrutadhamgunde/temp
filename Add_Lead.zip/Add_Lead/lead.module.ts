import { ModuleWithProviders, NgModule } from '@angular/core';
import { RouterModule } from '@angular/router';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { FormlyModule, FormlyBootstrapModule } from 'ng-formly';


import { AuthGuard, SharedModule } from '../shared';
import { LeadService } from './lead.service';
import { WorkflowConfigService } from './workflowConfig.service';
import { FormlyDatePicker } from './datePicker';

import { AddLeadComponent } from '../lead/add-lead/add-lead.component';
import { MyLeadComponent } from '../lead/my-lead/my-lead.component';
import { MyQueueComponent } from '../lead/my-queue/my-queue.component';
import { MyDatePickerModule } from 'mydatepicker';
import {OrderrByPipe} from '../shared/pipes/orderby.pipe';

const addLeadRouting: ModuleWithProviders = RouterModule.forChild([
  {
    path: 'lead/add-lead',
    component: AddLeadComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'lead/my-lead',
    component: MyLeadComponent,
    canActivate: [AuthGuard]
  },
  {
    path: 'lead/my-queue',
    component: MyQueueComponent,
    canActivate: [AuthGuard]
  }
]);

@NgModule({
  imports: [
    SharedModule,
    addLeadRouting,
    NgbModule.forRoot(),
    MyDatePickerModule,
    FormlyModule.forRoot({
      types: [{
        name: 'datepicker', component: FormlyDatePicker, extends: 'input'
      }]
    }),
    FormlyBootstrapModule,
    FormsModule,
    ReactiveFormsModule,
  ],
  declarations: [
    AddLeadComponent,
    MyLeadComponent,
    MyQueueComponent,
    FormlyDatePicker,
    OrderrByPipe
  ],
  providers: [LeadService,WorkflowConfigService]
})
export class AddLeadModule { }
