import { Injectable } from '@angular/core';

@Injectable()
export class WorkflowConfigService {
  defaults() {
    return {
      loaderImage : 'assets/images/loader.gif',
      workflow: [{
              id: 1,
              product: "PostPaid",
              leadStage: "L3Submitted",
              crifResult: "Accept",
              documentStatus: "All 7 documents uploaded",
              nextApplicationStatus: "Logged in"
          }, {
              id: 2,
              product: "PostPaid",
              leadStage: "L3Submitted",
              crifResult: "Refer",
              documentStatus: "All 7 documents uploaded",
              nextApplicationStatus: "Referred"
          }, {
              id:3,
              product: "PostPaid",
              leadStage: "L3Submitted",
              crifResult: "Not equal to Accept neither Refer",
              documentStatus: "All 7 documents uploaded",
              nextApplicationStatus: "Sales Reject"
          }, {
              id: 4,
              product: "Prepaid",
              leadStage: "L3Submitted",
              crifResult: "CRIF result is not pulled",
              documentStatus: "All 7 documents uploaded",
              nextApplicationStatus: "Logged in"
          }, {
              id: 5,
              product: "Prepaid",
              leadStage: "L3Submitted",
              crifResult: "CRIF result is not pulled",
              documentStatus: "All 7 documents uploaded",
              nextApplicationStatus: "Logged in"
          }, {
              id: 6,
              product: "Prepaid",
              leadStage: "L3Submitted",
              crifResult: "CRIF result is not pulled",
              documentStatus: "All 7 documents uploaded",
              nextApplicationStatus: "Logged in"
          }, {
              id: 7,
              product: "PostPaid",
              leadStage: "L3Submitted",
              crifResult: "Accept",
              documentStatus: "Any one or more documents are not uploaded",
              nextApplicationStatus: "L3Submitted"
          }, {
              id: 8,
              product: "PostPaid",
              leadStage: "L3Submitted",
              crifResult: "Refer",
              documentStatus: "Any one or more documents are not uploaded",
              nextApplicationStatus: "L3Submitted"
          }, {
              id: 9,
              product: "PostPaid",
              leadStage: "L3Submitted",
              crifResult: "Not equal to Accept neither Refe",
              documentStatus: "Any one or more documents are not uploaded",
              nextApplicationStatus: "L3Submitted"
          }, {
              id: 10,
              product: "Prepaid",
              leadStage: "L3Submitted",
              crifResult: "CRIF result is not pulled",
              documentStatus: "Any one or more documents are not uploaded",
              nextApplicationStatus: "L3Submitted"
          }, {
              id: 11,
              product: "Prepaid",
              leadStage: "L3Submitted",
              crifResult: "CRIF result is not pulled",
              documentStatus: "Any one or more documents are not uploaded",
              nextApplicationStatus: "L3Submitted"
          }, {
              id: 12,
              product: "Prepaid",
              leadStage: "L3Submitted",
              crifResult: "CRIF result is not pulled",
              documentStatus: "Any one or more documents are not uploaded",
              nextApplicationStatus: "L3Submitted"
          }

      ],
      applicationStatusList:[
        { id: 1, name:'LevelOneSubmitted'},
        { id: 2, name:'LevelTwoSubmitted'},
        { id: 3, name:'LevelThreeSubmitted'},
        { id: 4, name:'SalesRejected'},
        { id: 5, name:'LoggedIn'},
        { id: 6, name:'CreditApprovedLevel1'},
        { id: 7, name:'CreditRejectedLevel1'},
        { id: 8, name:'CreditRefferedLevel1'},
        { id: 9, name:'CreditCommitteeApproved'},
        { id: 10, name:'CreditCommitteeQueryOpen'},
        { id: 11, name:'CreditCommitteeRejected'},
        { id: 12, name:'Disbursed'},
        { id: 13, name:'WithDrawn'}
      ]


        
    };
  }
}
