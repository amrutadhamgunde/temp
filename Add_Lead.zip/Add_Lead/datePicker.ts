import { Component, OnInit } from '@angular/core';
import {FormsModule, ReactiveFormsModule, Validators, FormBuilder, FormGroup} from '@angular/forms';
import {FormlyModule, FormlyFieldConfig, FormlyBootstrapModule, Field, FieldWrapper} from 'ng-formly';
import {NgbModule} from '@ng-bootstrap/ng-bootstrap';


@Component({
  selector: 'formly-datepicker',
  template: `
      <div class="form-group">
    <div class="input-group">
       <input class="form-control" placeholder="yyyy-mm-dd" name="dp" [formControl]="formControl"  [minDate]="minDate" [maxDate]='maxDate' ngbDatepicker #d="ngbDatepicker">
      <div class="input-group-addon" (click)="d.toggle()" >
          <img src="assets/images/calendar.png" style="width: 2rem; cursor: pointer;"/>
      </div>
    </div>
  </div>
  `,
})
export class FormlyDatePicker extends Field {

   minDate = {year: 1920, month: 1, day: 1};
   maxDate = {year: 2050, month: 1, day: 1};

   
}
