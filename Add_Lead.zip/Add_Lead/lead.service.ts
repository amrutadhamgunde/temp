import { Injectable } from '@angular/core';
import { URLSearchParams, Headers } from '@angular/http';
import { Observable } from 'rxjs/Rx';
import 'rxjs/add/operator/map';
import { ApiService } from '../shared/services/api.service';
import { RequestOptions, Request, RequestMethod } from '@angular/http';

@Injectable()
export class LeadService {

  baseURL = "/api/mvp"
  constructor(
    private apiService: ApiService
  ) { }



  getContactDetails(data){
    return this.apiService.get(this.baseURL+'/contact/'+data)
      .map(
        (response: Response) => {
          return response;
        }
      )
      .catch(
        (error: Response) => {
          return Observable.throw('Something went wrong');
        }
      );
  }

searchCustomerInDashboard(data) {
    return this.apiService.post(this.baseURL + '/account/dashboard', data)
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }

  getCustomerDetails(data) {
    return this.apiService.post(this.baseURL + '/account/dashboard/details', data)
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }

  GetProductList() {
    return this.apiService.get(this.baseURL + '/get/primaryCategoryItems?categoryMasterId=4EE68207B1F6468F865511BC41A907D6')
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }

  GetoccuptionTypeS() {
    return this.apiService.get(this.baseURL + '/get/occuptionType')
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }

  GetSubProductList(ProductId) {
    return this.apiService.get(this.baseURL + '/get/secondaryCategoryItemByParentId?parentId=' + ProductId)
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }

  SearchLead(obj) {
    return this.apiService.post(this.baseURL + '/Lead/searchLeads', obj)
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }

  SearchQueue(obj) {
    return this.apiService.post(this.baseURL + '/lead/myqueue', obj)
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }

  GetLeadById(obj) {
    return this.apiService.get(this.baseURL + '/lead/getleadbyid?leadId=' + obj)
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }
  GetTemplateByProduct(obj) {
    return this.apiService.get(this.baseURL + '/dfb/gettemplatebytemplatecontext?context=' + obj)
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }




  fetchLoans() {
    return this.apiService.get(this.baseURL + '/get/primaryCategoryItems?categoryMasterId=249ea22038054f7fa83e5ce5d561ee0a')
      .map(
      data => {
        return data;
      }
      );
  }


  fetchSubproducts(productId) {
    return this.apiService.get(this.baseURL + '/get/secondaryCategoryItemByParentId?parentId=' + productId)
      .map(
      data => {
        return data;
      }
      );
  }


  fetchProducts(loanId) {

    return this.apiService.get(this.baseURL + '/get/secondaryCategoryItemByParentId?parentId=' + loanId)
      .map(
      data => {
        return data;
      }
      );
  }

  fetchTemplateById(templateId) {
    return this.apiService.get(this.baseURL + '/dfb/gettemplatebytemplatecontext?context=' + templateId)
      .map(
      data => {
        return data;
      }
      );
  }
  saveLead(data) {
    return this.apiService.post(this.baseURL + '/lead/addLead', data)
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }
  updateLead(data) {
    return this.apiService.post(this.baseURL + '/lead/editLead', data)
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }
  postTRN(data) {
    return this.apiService.post(this.baseURL + '/verify/retailCustomer', data)
      .map(
      data => {
        return data;
      }
      );
  }
  postB2BTRN(data) {
    return this.apiService.post(this.baseURL + '/verify/b2bCustomer', data)
      .map(
      data => {
        return data;
      }
      );
  }
  getFIRScore(data) {
    return this.apiService.post(this.baseURL + '/Lead/GetFIRResult', data)
      .map(
      data => {
        return data;
      }
      );
  }  

  uploadFile(formData: FormData) {
    const options = {};
    return this.apiService.post(this.baseURL + '/lead/upload/file', formData, options)
      .map(data => data);
  }

  updateLeadDocuments(data) {
    return this.apiService.post(this.baseURL + '/lead/uploadDocs', data)
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }
  getCreditHistory(data) {
    return this.apiService.post(this.baseURL + '/credithistory/Get/response', data)
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Credit score & Contract history not available, please try after sometime');
      }
      );
  }

   getCreditScore(data) {
    return this.apiService.post(this.baseURL + '/get/creditscore', data)
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Credit score & Contract history not available, please try after sometime');
      }
      );
  }

  getCreditScoreBusiness(data) {
    return this.apiService.post(this.baseURL + '/get/businesscreditscore', data)
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Credit score & Contract history not available, please try after sometime');
      }
      );
  }

  generateScore(data) {
    return this.apiService.post(this.baseURL + '/post/getcreditinfo' , data)
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Credit score & Contract history not available, please try after sometime');
      }
      );
  }

getCBScoreBusiness(data) {
 // data.DateofBirth=data.DateofBirth.formatted;
    return this.apiService.post(this.baseURL + '/post/generatecrifreport', data)
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Credit score & Contract history not available, please try after sometime');
      }
      );
  }
  leadDetailsById(data) {
    return this.apiService.get(this.baseURL + '/lead/getleadbyid?leadId=' + data)
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }
  fetchLeadDocument(data) {
    return this.apiService.post(this.baseURL + '/lead/getleaddocument', data)
      .map(
      data => {

        return data;
      }
      );
  }
  // cancel api
  CancelLeadApi(data) {
    return this.apiService.post(this.baseURL + '/lead/cancellationlead', data)
      .map(
      data => {

        return data;
      }
      );
  }

  // master apis start
  fetchCountries() {
    return this.apiService.get(this.baseURL + '/get/countries')
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }
  fetchCountriesbyId(id) {
    return this.apiService.get(this.baseURL + 'get/country?id=' + id)
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }
  fetchRegions() {
    return this.apiService.get(this.baseURL + '/get/regions')
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }
  fetchRegionsById(id) {
    return this.apiService.get(this.baseURL + '/get/region?id=' + id)
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }
  fetchStates() {
    return this.apiService.get(this.baseURL + '/get/states')
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }
  fetchStatesById(id) {
    return this.apiService.get(this.baseURL + '/get/state?id=' + id)
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }
  fetchCities() {
    return this.apiService.get(this.baseURL + '/get/cities')
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }
  fetchCitiesById(id) {
    return this.apiService.get(this.baseURL + '/get/city?id=' + id)
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }
  fetchAreas() {
    return this.apiService.get(this.baseURL + '/get/pincodes')
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }
  fetchAreasById(id) {
    return this.apiService.get(this.baseURL + '/get/area?id=' + id)
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }

  fetchOccupationType() {
    return this.apiService.get(this.baseURL + '/get/occuptionType')
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }

  fetchCompanyType() {
    return this.apiService.get(this.baseURL + '/get/CompanyType')
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }

  fetchBusinessType() {
    return this.apiService.get(this.baseURL + '/get/BusinessType')
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }

  fetchBaseBranches() {
    return this.apiService.get(this.baseURL + '/get/basebranches')
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }

  fetchContactType() {
    return this.apiService.get(this.baseURL + '/get/ContactType')
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }


  // master apis end

  DownloadContractHistory(data) {
    return this.apiService.getRawImage(this.baseURL + '/credithistory/Get/getflowreport?filename=' + data)
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }

  DownloadCreditHistory(data) {
    return this.apiService.getRawImage(this.baseURL + '/credithistory/Get/getflowreport?filename=' + data)
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }

  GetCreditHistoryScore(id) {
    return this.apiService.get(this.baseURL + '/credithistory/getcreditscorehistory?leadId=' + id)
      .map(
      data => {
        return data;
      }
      );
  }
  GetCreditHistoryB2BScore(data) {
    return this.apiService.post(this.baseURL + '/credithistory/Get/b2bresponse', data)
      .map(
      data => {
        return data;
      }
      );
  }

  workflowLeadLevelUpdate(data) {
    return this.apiService.post(this.baseURL + '/lead/UpdateLeadStatus', data)
      .map(
      (response: Response) => {
        return response;
      })
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      });
  }

SearchExixtingLead(data) {
    return this.apiService.post(this.baseURL + '/get/searchtrn', data)
      .map(
      (response: Response) => {
        return response;
      })
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      });
  }

  getNextApplicationStatus(data) {
    return this.apiService.post(this.baseURL + '/lead/getNextWorkFlowStatus', data)
      .map(
      (response: Response) => {
        return response;
      })
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      });
  }
  getFeedbackHistory(data) {
    return this.apiService.get(this.baseURL + '/lead/getleadfeedback?leadId=' + data)
      .map(
      (response: Response) => {
        return response;
      })
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      });
  }

  postUpdateLeadId(data) {
    return this.apiService.get(this.baseURL + '/update/updateleadId?LeadId=' + data)
      .map(
      (response: Response) => {
        return response;
      })
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      });
  }
  

  fileDownload(data) {
    return this.apiService.getRawImage(this.baseURL + '/download/file?fileName=' + data)
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }

  filePreview(data) {
    return this.apiService.getRawImage(this.baseURL + '/lead/download/file?fileName=' + data)
      .map(
      (response: Response) => {
        return response;
      }
      )
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      }
      );
  }

  submitOTP(data){
    return this.apiService.post(this.baseURL + '/lead/validateotp', data)
      .map(
      (response: Response) => {
        
          return response;
       
        
      })
      .catch(
      (error: Response) => {
        return Observable.throw('Something went wrong');
      });
  }

  

}
