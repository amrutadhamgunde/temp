import { Component, OnInit, ViewContainerRef, OnDestroy, ViewChild, HostListener } from '@angular/core';
import { IMyDpOptions, IMyDateModel } from 'mydatepicker';
import { FormsModule, ReactiveFormsModule, Validators, FormBuilder, FormGroup, FormControl } from '@angular/forms';
import { FormlyModule, FormlyFieldConfig, FormlyBootstrapModule, Field, FieldWrapper } from 'ng-formly';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';
import 'rxjs/add/operator/map';
import 'rxjs/add/operator/debounceTime';
import 'rxjs/add/operator/distinctUntilChanged';
import { ToastsManager } from 'ng2-toastr/ng2-toastr';
import { LeadService } from '../lead.service';
import { ActivatedRoute, Router } from '@angular/router';
import { FormlyFieldValidatorsService } from 'app/shared/validators/formly_field_validators';
import * as moment from 'moment/moment';
//import { WINDOW } from "./window.service";
@Component({
    selector: 'app-add-lead',
    templateUrl: './add-lead.component.html',
    styleUrls: ['./add-lead.component.css']
})

 
export class AddLeadComponent implements OnDestroy {
    @ViewChild('t') t;
   private myDatePickerOptions: IMyDpOptions = {
        // other options...
        // dateFormat: 'dd.mm.yyyy',
        editableDateField: false,
        inline: false
    };
    searchDataPaging: Array<any> = [];
    proceedDis;
    generateDis;
    searchLeadForm: FormGroup;
    form: FormGroup = new FormGroup({});
    filter: boolean = false;
    model: any = {};
    resultData = {};
    resultDataEmpty = true;
    template: any = [];
    tabs: Array<any> = [];
    values: Array<any> = [];
    templateJSON: Array<any> = [];
    products: Array<any> = [];
    loans: Array<any> = [];
    documentArray: Array<any> = [];
    documentArrayIsEmpty = true;
    noResult = false
    documentIndex = 0;
    DocumentTypes = [];
    companyTypes = [];
    productName: '';
    productId: '';
    subProductId: '';
    tempsubProductId: '';
    subproductName: '';
    decision: any = '';
    leadId: '';
    openTabId = '';
    checkMediaValidation;
    checkMediaValidationBusiness;
    proceedDisabled = false
    loanDis = false
    sub: any
    tempdate: any;
    leadJSON: any = {
        validationContext: '',
        leadData: {}
    }
    email: ''
    mobile: ''
    leveloneSubmitted = false;
    showCreditInfoButton = true;
    creditScoreResponse: Array<any> = [];
    templateSearch = false;
    creditHistoryFetch: boolean = false
    showCreditScore = false
    submitedData = false;
    profileImageSrc = 'assets/images/profile_pic.png';
    imageTemplate: any = {
        "className": "section-label",
        "template": "<div class='col-xs-6' style='text-align: center;''><h4>Customer Photograph From TAJ</h4><img class='custImage' style='height:235px; width:235px' src=" + this.profileImageSrc + "></div>"
    }
    businessLoan = false;
    consumerLoan = false;
    trnNo: '';
    changeLoanUp = false;
    existingLead = false;
    subproducts: Array<any> = [];
    private fields: Array<FormlyFieldConfig> = [];
    public minDate: Date = void 0;
    profileIdentifications = [];
    uploadDocObject = {};
    tabButtonTitle = "Proceed";
    activeTabId = "ngb-tab-0";
    docActive = false;
    productParent = 'empty';
    isPopedUp = false;
    //upload document name Retail start
    trnDocumentName = '';
    passportDocumentName = '';
    utilityBillDocumentName = '';
    jobLetterDocumentName = '';
    idProofFirstAuthorizedSignatoryName = '';
    idProofSecondAuthorizedSignatoryName = '';
    signedConsentName = '';
    cancelReason = 0;
    cancelRemarks = '';
    //upload document name Retail end
    //upload document name B2B start
    companyTRNName = "";
    CompanyRegistrationDocName = "";
    CertificateofIncorporationName = "";
    IDofprimaryapplicantName = "";
    SignedConsentFormName = "";
    loanId = "";
    loanName = '';
	reportData;
    //upload document name B2B end
    formErrors = {
        'trnNumber': '',
    };
    IsLoaderActive = false;
    existingLead1 = false;
    submitLevel1 = true;
	filename;
	score;
	currentDateTime;
    x = 0;
    lead = {
        'DOB': '',
    }
    a = 1;
    contact = {
        'productGroupId': '',
        'LoanId': '',
        "id": "",
        "firstName": "",
        "lastName": "",
        "mobile": "",
        "email": "",
        "campaignName": "",
        "addressLine1": "",
        "addressLine2": "",
        "cityName": "",
        "cityId": "",
        "stateName": "",
        "stateId": "",
        "pinCode": null,
        "area": null,
        "branchName": null,
        "branchId": "",
        "productId": "",
        "productName": "",
        "subProductId": "",
        "subProductName": "",
        "dateofbirth": "",
        "trn": ""
    }
    postcodes;
    cities;
    scoreRating;
    taxRegistrationNumberName = '';
    referenceLetterName = '';
    companyRegistrationCertificateName = '';
    businessLicenceName = '';
    directionsToBusinessName = '';
    photographsOfBusinessPlaceName = '';
    licenceDocumentName = '';
    passportPhotograhDocumentName = '';
    electricityBillDocumentName = '';
    phoneBill = '';
    bankStatement = '';
    jobLetter = '';
    payInSlip3Months = '';
    guarantorLetter = '';
    assetPurchaseReciept = '';
    letterOfHypothecation = '';
    motorVehicleTitle = '';
    stockCertificate = '';
    signedConsentForm = '';
    creditBureuReport = '';
    clientSignature = '';
    uploadDocCount;
    existingLeadsearchPop = false
    contactId: string
    otpPop = false
    y: number;
	reportLoader;
    creditReport = null
    tryLater = null

    otp = null
    leadCheck = null
    scoreCard = ""


    customerTypeFlag = 0;

    constructor(
        private fb: FormBuilder,
        private router: Router,
        private route: ActivatedRoute,
        public toastr: ToastsManager, vcr: ViewContainerRef,
        private leadService: LeadService,
        public ffv: FormlyFieldValidatorsService) {
        this.checkMediaValidation = 1;
        this.checkMediaValidationBusiness = 1;
        this.toastr.setRootViewContainerRef(vcr);
        this.form = this.fb.group({
            trnNumber: ['', [Validators.required, Validators.minLength(9), Validators.maxLength(9)]],
            firstNameNew: '',
            lastNameNew: '',
            dateOfBirthNew: '',
            B2BCompanyName: '',
            B2BCompanyType: '',
            B2BTrnNumber: '',
            B2BBusinessNumber: '',
        });
        this.uploadDocCount = 0;
        this.proceedDis = true;
        this.generateDis = true;
        this.reportData = false;
		this.reportLoader = false;
        this.searchLeadForm = this.fb.group({
            subProductName: '',
            loanId: '',
            loanName: '',
            productId: '',
            subProductId: '',
        });

        this.searchLeadForm.controls['loanId'].reset({ value: '', disabled: false });
        this.leadService
            .fetchLoans()
            .subscribe((loans: any[]) => {
                this.loans = loans;
                if (this.loans) {
                }
            }, error => {

            });

        this.model = {
            'isMailingAddressSameAsAbove': "Yes",
            'nationality': '7ac48140fac845b3b6febf7352061b4e',
            'country': '7ac48140fac845b3b6febf7352061b4e',
            'mailingCountry': '7ac48140fac845b3b6febf7352061b4e',
            'employerCountry': '7ac48140fac845b3b6febf7352061b4e',
            'alternateContactCountry': '7ac48140fac845b3b6febf7352061b4e',
            'additionalCountry': '7ac48140fac845b3b6febf7352061b4e',
            'totalIncome': 0,
            'parish':'',
            'town':'',
            'postOfficeCode':'',
        }
        this.minDate = new Date(1950, 1, 1);
    }

    getProduct(loanId) {
        console.log(loanId);
        for (var i = 0; i < this.loans.length; i++) {
            if (this.loans[i]['id'] == loanId) {
                this.loanName = this.loans[i]['name'];
            }
        }

        if (this.leadId != "" && this.leadId != undefined) {

            this.changeLoanUp = true;
        }
        if (loanId != "" && loanId != undefined) {
            this.leadService.fetchProducts(loanId).subscribe((products: any[]) => {
                this.products = products;
                this.subproducts = [];
                this.template = [];
                this.documentArrayIsEmpty = true;
                this.x = 0;
            }, error => {

            });
        } else {
            this.products = [];
            this.subproducts = [];
            this.template = [];
            this.documentArrayIsEmpty = true;
            this.model = '';
        }
       
    }


    getSubProduct(productId) {
        for (var i = 0; i < this.products.length; i++) {
            if (this.searchLeadForm.value.productId == this.products[i]["name"]) {
                this.productParent = this.products[i]["parentName"];
                
            }
        }

        var temp = this.products.filter(x => x.id === productId);
        //if (typeof (temp) !== "undefined" && temp !== null) 
        if (productId != "" && productId != undefined){
            this.productName = temp[0].name;
            this.productId = temp[0].id
            this.leadService.fetchSubproducts(this.productId).subscribe((subproducts: any[]) => {
                this.subproducts = subproducts;         
            }, error => {

            });
        }else {
            //this.products = [];
            this.subproducts = [];
            this.template = [];
            this.documentArrayIsEmpty = true;
            this.model = '';
        }

    }

    ngOnInit() {
        this.sub = this.route.params.subscribe(params => {
            this.contactId = params['id'];
            let x = this.contactId;
            if (this.contactId) {
                this.leadService.getContactDetails(this.contactId).subscribe((contact: any) => {
                    this.contact = contact;
                    if (this.contact) {
                        this.getProduct1(this.contact.productGroupId)
                        this.searchLeadForm.patchValue({
                            loanId: this.contact.productGroupId
                        })
                    }
                },
                    (error) => console.log("error at view contact details --> " + error)
                );
            }
        });
    }



    getProduct1(loanId) {
        for (var i = 0; i < this.loans.length; i++) {
            if (this.loans[i]['id'] == loanId) {
                this.loanName = this.loans[i]['name'];
            }
        }

        //  this.searchLeadForm
        if (this.searchLeadForm["controls"]["subProductId"].value != "") {
            this.changeLoanUp = true;
        }
        this.leadService.fetchProducts(loanId).subscribe((products: any[]) => {
            this.products = products;
            this.getSubProduct1(this.contact.productId)
        }, error => {

        });
        this.searchLeadForm.patchValue({
            productId: this.contact.productId,
        })
    }

    getSubProduct1(productId) {
        for (var i = 0; i < this.products.length; i++) {
            if (this.searchLeadForm.value.productId == this.products[i]["name"]) {
                this.productParent = this.products[i]["parentName"];
            }
        }

        var temp = this.products.filter(x => x.id === productId);
        this.productName = temp[0].name;
        this.productId = temp[0].id
        this.leadService.fetchSubproducts(productId).subscribe((subproducts: any[]) => {
            this.subproducts = subproducts;
            this.IsLoaderActive = false;
            this.getTemplate(this.contact.subProductId)
        }, error => {

        });
        this.searchLeadForm.patchValue({
            subProductId: this.contact.subProductId,
        })
    }

    clickme(data, form) {
        console.log('data');
        console.log(data);
        console.log('form');
        console.log(form);
        console.log(data.netSales);
        console.log(this.template);
        //this.template[0].sections[0].fields[2];
        this.template[1].sections[1].groups[0].fields[2].templateOptions.label = "Address Line 2";
        this.template[1].sections[1].groups[0].fields[2].value = "200";
        //this.model.totalIncome = 100;
        var netSales = Number(data.netSales || 0);
        var otherIncome = Number(data.otherIncome || 0);
        var totalIncome = netSales + otherIncome;
        console.log('totalIncome : ' + totalIncome);

        this.model.totalIncome = totalIncome;
        // this.model['totalIncome'] = totalIncome;
        console.log('resetModel');
        /*angular.forEach( form, function( field ) {
         console.log(field);
    
         });
         this.field.resetModel();*/
    }
    doActionOn() {
        console.log('in Doaction');
    }

    getTemplate(subProductId) {
        this.model = {};
        //this.form.reset();
        this.model = {
            'isMailingAddressSameAsAbove': "Yes",
            'nationality': '7ac48140fac845b3b6febf7352061b4e',
            'country': '7ac48140fac845b3b6febf7352061b4e',
            'mailingCountry': '7ac48140fac845b3b6febf7352061b4e',
            'employerCountry': '7ac48140fac845b3b6febf7352061b4e',
            'alternateContactCountry': '7ac48140fac845b3b6febf7352061b4e',
            'additionalCountry': '7ac48140fac845b3b6febf7352061b4e',
            'totalIncome': 0,
            'parish':'',
            'town': '',
            'postOfficeCode': '',
            'gender': 'Please Select',
            'customerType' : 'Please Select'           
        }

if (this.productParent == "Consumer Loan"){
    this.model = {
                'income': 'Please Select',
                'dependents': 'Please Select',
                'creditScoreCIP': 'Please Select',
                'collateral': 'Please Select',
                'conditions': 'Please Select',
                'repaymentMethod': 'Please Select',
                'jobStability': 'Please Select',
                'residentialStability': 'Please Select',
                'dSRPERSONALLOANEXTERNAL': 'Please Select',
                'dSRSECUREDLOANS': 'Please Select',
            };

}
        this.tempsubProductId = subProductId;
        this.templateSearch = true;
        var temp2 = this.subproducts.filter(x => x.id === subProductId);//this.search(subProductID,this.subproducts)
        this.subproductName = temp2[0].name
        var templateId = this.productName + ':' + this.subproductName;
        if (templateId.includes("+")) {
            templateId = templateId.replace("+", "%2B")
        }
        this.tempdate = this.leadService.fetchTemplateById(templateId).subscribe((result) => {
            this.template = result.templatedata;
            if (!((this.contact.trn == null) || (this.contact.trn == undefined) || (this.contact.trn == ""))) {
				//this.contact.dateofbirth="1982-11-11";
                 var splitEndDate = this.contact.dateofbirth.split('/');
				 let a =
					{
						"year": +splitEndDate[2],
						"month": +splitEndDate[0].replace(/(^0)/g, ""),
						"day": +splitEndDate[1].replace(/(^0)/g, ""),
					};
				//this.form.controls['dateOfBirth'].setValue("1982-05-05");
                this.model.dateOfBirth = a;

                this.model.tRN = this.contact.trn;
                this.model.firstName = this.contact.firstName;
                this.model.lastName = this.contact.lastName;
                this.model.mobileNumber = this.contact.mobile;
                this.model.customerType = 'Existing';
               
            }
            for (var i = 0; i < this.template.length; i++) {
                if (this.template[i]["name"] == "Upload Media") {
                    this.documentArray = this.template[i];
                    this.documentIndex = i;
                    this.documentArrayIsEmpty = false;
                }
            }
            console.log(this.documentArray);
            this.template[0].sections[1].fields[10] = {
                className: "col-xs-12",
                key: 'consentcheckbox',
                type: 'checkbox',
                templateOptions: {
                    label: 'Customer has given consent to proceed with the application',
                },
            };
            this.template[0].sections[0].fields[2] = {
                className: "col-xs-6",
                key: "firstName",
                type: "input",
                ngModelElAttrs: {
                    'ng-change': this.doActionOn()
                },
                controller: function ($scope) {
                    $scope.myFunc = function () {
                        console.log('Another text');
                    };
                },
                templateOptions: {
                    focus: false,
                    label: "First Name",
                    maxlength: "30",
                    minlength: "3",
                    placeholder: "",
                    required: false,
                    type: "input",
                    value: "",
                    onChange: function () {
                        console.log('coming in here');
                    }
                },
            };
            this.template[0].sections[1].fields[11] = {
                "className": "col-xs-3",
                "defaultValue": "",
                "template": `Result: <label>&nbsp;&nbsp;&nbsp;&nbsp;</label>`,
                "type": "input",
            };
            
            this.leadService.fetchCountries().subscribe((loans: any[]) => {              
                    if (this.loans) {
                        var optionsData = [];
                        for (var i = 0; i < loans.length; i++) {
                            optionsData.push({ "label": loans[i]["name"], "value": loans[i]["id"] })
                        }
                        if (this.productParent == "Consumer Loan") {
                            this.template[0].sections[2].fields[10].templateOptions.options = optionsData;
                            this.template[0].sections[2].fields[10].templateOptions.disabled = true;
                        }
                        else {
                            this.template[0].sections[2].fields[7].templateOptions.options = optionsData;
                            //this.template[0].sections[2].fields[7].templateOptions.options = '7ac48140fac845b3b6febf7352061b4e';
                            this.template[0].sections[2].fields[7].templateOptions.disabled = true;
                            this.template[2].sections[0].fields[6].templateOptions.options = optionsData
                            this.template[2].sections[0].fields[14].templateOptions.options = optionsData
                        }
                        this.template[2].fields[9].templateOptions.options = optionsData;
                    }
                }, error => {

                });
            this.leadService.fetchStates().subscribe((loans: any[]) => {
                    if (this.loans) {
                        var optionsData = [];
                        for (var i = 0; i < loans.length; i++) {
                            if (i == 0){
                                optionsData.push({ "label": "Please Select", "value": "" })
                            }
                            optionsData.push({ "label": loans[i]["name"], "value": loans[i]["id"] })
                        }
                        if (this.productParent == "Consumer Loan") {
                            this.template[0].sections[2].fields[5].templateOptions.options = optionsData;
                            this.template[2].fields[8].templateOptions.options = optionsData;
                        }
                        else {
                            this.template[0].sections[2].fields[2].templateOptions.options = optionsData;
                            this.template[2].sections[0].fields[5].templateOptions.options = optionsData
                            this.template[2].sections[0].fields[13].templateOptions.options = optionsData
                        }
                    }
                }, error => {

                });

            this.leadService.fetchCities().subscribe((cities: any[]) => {
                    this.cities = cities;
                    if (this.cities) {
                        var optionsData = [];
                        for (var i = 0; i < cities.length; i++) {
                            if (i == 0){
                                optionsData.push({ "label": "Please Select", "value": "" })
                            }
                            optionsData.push({ "label": cities[i]["name"], "value": cities[i]["id"] })
                        }
                        if (this.productParent == "Consumer Loan") {
                            this.template[0].sections[2].fields[6].templateOptions.options = optionsData;
                            this.template[2].fields[5].templateOptions.options = optionsData;
                        }
                        else {
                            this.template[0].sections[2].fields[3].templateOptions.options = optionsData;
                            this.template[2].sections[0].fields[4].templateOptions.options = optionsData
                            this.template[2].sections[0].fields[12].templateOptions.options = optionsData
                        }

                    }
                }, error => {

                });

            this.leadService
                .fetchAreas()
                .subscribe((postcodes: any[]) => {
                    this.postcodes = postcodes;
                    if (this.postcodes) {
                        var optionsData = [];
                        for (var i = 0; i < postcodes.length; i++) {
                            if (i == 0){
                                optionsData.push({ "label": "Please Select", "value": "" })
                            }
                            optionsData.push({ "label": postcodes[i]["value"], "value": postcodes[i]["id"] })
                        }
                        if (this.productParent == "Consumer Loan") {
                            this.template[0].sections[2].fields[7].templateOptions.options = optionsData;
                            this.template[2].fields[6].templateOptions.options = optionsData;
                        }
                        else {
                            this.template[0].sections[2].fields[4].templateOptions.options = optionsData;
                        }
                    }
                }, error => {

                });

             //this.model.town = "Bath"
             //this.model.addressLine2 = "Select"
            this.template.pop();
            this.templateSearch = false;
            this.productParent = this.loanName;
            this.tab(this.template);
            if (this.productParent == "Business Loan") {
                
                this.businessLoan = true;
            }
            else if (this.productParent == 'Consumer Loan') {
                this.consumerLoan = true;
            }
            if (!this.documentArrayIsEmpty) {
                this.template.splice(this.documentIndex, 1);
            }
            this.documentArrayIsEmpty = false;
            this.template[1].active = false;
        }, error => {

        });
    }

    tab(template) {
        this.template[1].active = false;
        this.template[2].active = false;
    }
    genarateProceed() {
        this.y = 0;
        this.submit(this.y);
    }

    isArray = function (a) {
        return (!!a) && (a.constructor === Array);
    };

    get_credit_score() {
        if (this.productParent == "Consumer Loan") {
            var data = {
                "Income": this.model['income'],
                "Dependents": this.model['dependents'],
                "CreditScoreCIP": this.model['creditScoreCIP'],
                "Collateral": this.model['collateral'],
                "Conditions": this.model['conditions'],
                "RepaymentMethod": this.model['repaymentMethod'],
                "JobStability": this.model['jobStability'],
                "ResidentialStability": this.model['residentialStability'],
                "DSRPersonalLoadExternal": this.model['dSRPERSONALLOANEXTERNAL'],
                "DSRSecuredLoans": this.model['dSRSECUREDLOANS'],
            };
            this.leadService.getCreditScore(data).subscribe((products: any[]) => {
                this.scoreRating = products['scoreCardRating'];
                if (products['scoreCardRating'] == 'APPROVE LOAN') {
                    //this.template[0].sections[1].fields[11]['className'] = "col-xs-3 red";
                    this.template[0].sections[1].fields[11]['template'] = "Result: <label>" + products['scoreCardRating'] + "</label>";
                }
                else if (products['scoreCardRating'] == 'ACCEPT') {
                    //this.template[0].sections[1].fields[11]['className'] = "col-xs-3 green";
                    this.template[0].sections[1].fields[11]['template'] = "Result: <label>" + products['scoreCardRating'] + "</label>";
                }
                else if (products['scoreCardRating'] == "S/D & GUARANTOR") {
                    //this.template[0].sections[1].fields[11]['className'] = "col-xs-3 amber";
                    this.template[0].sections[1].fields[11]['template'] = "Result: <label>" + products['scoreCardRating'] + "</label>";
                }
                else if (products['scoreCardRating'] == "REFER") {
                    //this.template[0].sections[1].fields[11]['className'] = "col-xs-3 amber";
                    this.template[0].sections[1].fields[11]['template'] = "Result: <label>" + products['scoreCardRating'] + "</label>";
                }
                else {
                    products['scoreCardRating'] = "REJECT"
                    this.template[0].sections[1].fields[11]['template'] = "Result: <label>" + "REJECT" + "</label>";

                }

                if (this.model["consentcheckbox"] && products['scoreCardRating'] != 'REJECT') {
                    this.generateDis = false;
                }
                else
                    this.generateDis = true;


            }, error => {

            });
        }
        else {
            this.get_credit_score_business();
        }
    }
    get_credit_score_business() {
        var data = {
            "MaritalStatus": this.model['maritalStatus'],
            "NumberOfDependents": this.model['noOfDependents'],
            "ResidentialStability": this.model['residentialStability'],
            "ResidentialStatus": this.model['residentialStatus'],
            "BusinessStability": this.model['businessStability'],
            "ApplicantFormalSystem": this.model['alreadyInAFormalSystem:HirePurchase,BankEtc'],
            "CreditReportStatus": this.model['creditReportStatus'],
            "OtherIncome": this.model['capacityFromOtherIncome'],
        };
        this.leadService.getCreditScoreBusiness(data).subscribe((products: any[]) => {
            this.scoreRating = products['scoreCardRating'];
            //console.log(products['scoreCardRating']);

            if (products['scoreCardRating'] == 'APPROVE LOAN') {
                //this.template[0].sections[1].fields[11]['className'] = "col-xs-3 red";
                this.template[0].sections[1].fields[11]['template'] = "Result: <label>" + products['scoreCardRating'] + "</label>";
            }
            else if (products['scoreCardRating'] == 'ACCEPT') {
                //this.template[0].sections[1].fields[11]['className'] = "col-xs-3 green";
                this.template[0].sections[1].fields[11]['template'] = "Result: <label>" + products['scoreCardRating'] + "</label>";
            }
            else if (products['scoreCardRating'] == "S/D & GUARANTOR") {
                //this.template[0].sections[1].fields[11]['className'] = "col-xs-3 amber";
                this.template[0].sections[1].fields[11]['template'] = "Result: <label>" + products['scoreCardRating'] + "</label>";
            }
            else if (products['scoreCardRating'] == "REFER") {
                //this.template[0].sections[1].fields[11]['className'] = "col-xs-3 amber";
                this.template[0].sections[1].fields[11]['template'] = "Result: <label>" + products['scoreCardRating'] + "</label>";
            }
            else {
                products['scoreCardRating'] = "REJECT"
                this.template[0].sections[1].fields[11]['template'] = "Result: <label>" + "REJECT" + "</label>";

            }

            if (this.model["consentcheckbox"] && products['scoreCardRating'] != 'REJECT') {
                this.generateDis = false;
            }
            else
                this.generateDis = true;


        }, error => {

        });

    }
    generate_report() {
        var patternTrn = /(^0$)|(^[1-9]\d{0,8}$)/;
        var patternName = /^[a-zA-Z]*$/;
        var patternMobile = /(^0$)|(^[1-9]\d{0,9}$)/;
        var patternInvest = /^[1-9]\d*$/;

        if (this.model.customerType == '' || this.model.customerType == null || this.model.customerType == "Please Select") {
            this.toastr.warning("Customer Type is Required");
            return
        }

        if (this.model.tRN == null || this.model.tRN == "") {
            this.toastr.warning("TRN is Required");
            return
        }

        if (this.model.tRN.length > 9) {
            this.toastr.warning("TRN length cannot be more than 9");
            return
        }

        else if (this.model.tRN != null && this.model.tRN != "") {
            if (!this.model.tRN.match(patternTrn)) {
                this.toastr.warning("Invalid TRN");
                return
            }
        }

        if (this.model.firstName == null || this.model.firstName == "") {
            this.toastr.warning("First Name is Required");
            return
        }
        if (this.model.firstName != null && this.model.firstName != "") {
            if (!this.model.firstName.match(patternName)) {
                this.toastr.warning("Invalid First Name");
                return
            }
            else if (this.model.firstName.length > 30) {
                this.toastr.warning("First Name length cannot be more than 30");
                return
            }
        }

        if (this.model.lastName == null || this.model.lastName == "") {
            this.toastr.warning("Last Name is Required");
            return

        }

        if (this.model.lastName != null && this.model.lastName != "") {
            if (!this.model.lastName.match(patternName)) {
                this.toastr.warning("Invalid Last Name");
                return
            }
            else if (this.model.lastName.length > 30) {
                this.toastr.warning("Last Name length cannot be more than 30");
                return
            }
        }
        if (this.model.dateOfBirth == '' || this.model.dateOfBirth == null) {
            this.toastr.warning("Date of Birth is Required");
            return
        }

        if (this.model.mobileNumber == '' || this.model.mobileNumber == '') {
            this.toastr.warning("Mobile Number is Required");
            return
        }

        if (this.model.mobileNumber.length > 10) {
            this.toastr.warning("Mobile Number length cannot be more than 10");
            return
        }

        else if (this.model.mobileNumber != null && this.model.mobileNumber != "") {
            if (!this.model.mobileNumber.match(patternMobile)) {
                this.toastr.warning("Invalid Mobile Number");
                return
            }
        }

        if ((this.model.loanAmount == null && this.productParent == "Business Loan") || (this.model.loanAmount == "" && this.productParent == "Business Loan")) {
            this.toastr.warning("Loan amount is Required");
            return
        }

        if ((this.model.loanAmount != null && this.productParent == "Business Loan") && (this.model.loanAmount != "" && this.productParent == "Business Loan")) {
            if (!this.model.loanAmount.match(patternInvest)) {
                this.toastr.warning("Invalid Loan amount");
                return
            }
            else if (this.model.loanAmount.length > 20) {
                this.toastr.warning("Loan amount length cannot be more than 20");
                return
            }
        }

        if ((this.model["loanTenure(InMonths)"] == null && this.productParent == "Business Loan") || (this.model["loanTenure(InMonths)"] == "" && this.productParent == "Business Loan")) {
            this.toastr.warning("Loan tenure is Required");
            return
        }

        if ((this.model["loanTenure(InMonths)"] != null && this.productParent == "Business Loan") && (this.model["loanTenure(InMonths)"] != "" && this.productParent == "Business Loan")) {
            if (!this.model["loanTenure(InMonths)"].match(patternInvest)) {
                this.toastr.warning("Invalid Loan tenure");
                return
            }
            else if (this.model["loanTenure(InMonths)"].length > 20) {
                this.toastr.warning("Loan tenure length cannot be more than 20");
                return
            }
        }
        var currentDate = moment().format('DD-MMM-YYYY hh:mm');
        this.currentDateTime = currentDate;
        if (this.productParent == "Consumer Loan") {

             if (this.model.tRN != ""){      
                 var data1 = {
					"IDNumber": this.model.tRN,
					"IDNumbertype": "TaxNumber",
					"InquiryReason":"ApplicationForCreditOrAmendmentOfCreditTerms"
			  } 
              this.reportLoader = true;
            this.leadService.generateScore(data).subscribe((score: any) => {

				this.reportLoader = false;
				this.filename = score.filename;
				this.score = score.score;
				console.log(this.filename);
				console.log(this.score);
					if (this.model["consentcheckbox"] && this.scoreRating != 'REJECT') {
						 this.proceedDis = false;
						this.reportData = true;
						var imagetype = "pdf";
					}
            }, error => {

            });
            }
        }

        if (this.productParent == "Business Loan") {
            if (typeof (this.model.dateOfBirth) == 'object') {
                let year = this.model.dateOfBirth["year"].toString();
                let month = this.model.dateOfBirth["month"].toString().length == 1 ? '0' + this.model.dateOfBirth["month"].toString() : this.model.dateOfBirth["month"].toString();
                let day = this.model.dateOfBirth["day"].toString().length == 1 ? '0' + this.model.dateOfBirth["day"].toString() : this.model.dateOfBirth["day"].toString();
                var date = month + '/' + day + '/' + year;
            }
            var data = {
                "FirstName": this.model.firstName,
                "LastName": this.model.lastName,
                "DateofBirth": date,
                "TRN": this.model.tRN,
                "MiddleName": null,
                "StreetNumAndName": null,
                "InstallmentNum": this.model["loanTenure(InMonths)"],
                "Amount": this.model.loanAmount,
                "Periodicity": "M",
                "Product": this.productName,
                "SubProduct": this.subproductName
            }
            this.reportLoader = true;
            this.leadService.getCBScoreBusiness(data).subscribe((score: any) => {
				this.reportLoader = false;
                /*this.scoreCard = "Credit Score : "
                this.creditReport = "Credit Report Generated on";
                this.tryLater = "";*/
                this.filename = score.filename;
				this.score = score.score;
				console.log(this.filename);
				console.log(this.score);
                if (this.model["consentcheckbox"] && this.scoreRating != 'REJECT') {
                    this.proceedDis = false;
					this.reportData = true;
                    var imagetype = "pdf";
                    /*this.leadService.fileDownload(filename).subscribe(res => {
                            if (imagetype == "pdf") {
                                var mediaType = 'application/pdf';
                            } else if (imagetype == "txt") {
                                var mediaType = 'text/plain';
                            } else if (imagetype == "xls") {
                                var mediaType = 'application/excel';

                            } else if (imagetype == "doc") {
                                var mediaType = 'application/msword';
                            } else {
                                var mediaType = 'image/jpeg';
                            }
							
                            var file = new Blob([res.blob()], { type: mediaType });
                            if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                                window.navigator.msSaveOrOpenBlob(file);
                            } else {
                                let url = window.URL.createObjectURL(file);
                                window.open(url, '_blank');
                            }
                        });*/
                }

            }, error => {
                this.proceedDis = true;
                /*this.scoreCard = "Credit Score : "
                this.creditReport = "Credit Report Generated on";
                this.tryLater = "Please try again later";*/

            });
        }
    }
	
	downloadFile(filename){
		 var imagetype = "pdf";
		this.leadService.fileDownload(filename).subscribe(res => {
			if (imagetype == "pdf") {
				var mediaType = 'application/pdf';
			} else if (imagetype == "txt") {
				var mediaType = 'text/plain';
			} else if (imagetype == "xls") {
				var mediaType = 'application/excel';

			} else if (imagetype == "doc") {
				var mediaType = 'application/msword';
			} else {
				var mediaType = 'image/jpeg';
			}
			
			var file = new Blob([res.blob()], { type: mediaType });
			if (window.navigator && window.navigator.msSaveOrOpenBlob) {
				window.navigator.msSaveOrOpenBlob(file);
			} else {
				let url = window.URL.createObjectURL(file);
				window.open(url, '_blank');
			}
		});
	}
    ngOnDestroy() {
        window.location.reload();
        this.activeTabId = ''
    }

    redirectHome() {
        this.isPopedUp = false;
        this.router.navigate(['']);
    }
    cancelApiCall() {
        if (this.leadId != undefined) {
            let data = {
                "CancellationReasonId": this.cancelReason,
                "Remarks": this.cancelRemarks,
                "LeadId": this.leadId,
            }
            this.leadService.CancelLeadApi(data).subscribe((d: any) => {
                    this.isPopedUp = false;
                    this.toastr.success("Lead cancelled successfully.");
                    setTimeout(() => {
                        this.router.navigate(['']);
                    }, 2000);
                });
        }
        else {
            this.isPopedUp = false;
            this.toastr.error("You need to save lead before cancel!");
        }

    }
    crdithistory() {

        if (this.model.customerType == '') {
            this.toastr.warning("Customer Type is Required");
            return
        }
        if (this.model.tRN == null) {
            this.toastr.warning("TRN is Required");
            return
        }
        if (this.model.firstName == null) {
            this.toastr.warning("First Name is Required");
            return
        }
        if (this.model.lastName == null) {
            this.toastr.warning("Last Name is Required");
            return
        }
        if (this.model.dateOfBirth == '') {
            this.toastr.warning("Date of Birth is Required");
            return
        }

        this.creditHistoryFetch = true;
        let creditInfo = {
            firstName: this.model.firstName || '',
            lastName: this.model.lastName || '',
            tRN: this.form.value.trnNumber || '',
            docNumber: this.model.docNumber || '',
            docIssueDate: this.model.docIssueDate || '',
            dateofBirth: this.model.dateofBirth || ''
        }
        if (typeof (this.model.dateOfBirth) == 'object') {
            creditInfo.dateofBirth = (this.model.dateOfBirth["month"] + '/' + this.model.dateOfBirth["day"] + '/' + this.model.dateOfBirth["year"]).toString() || ''

        } else {
            creditInfo.dateofBirth = this.model.dateofBirth
        }

        this.leadService.getCreditHistory(creditInfo).subscribe((data: any) => {
                this.creditHistoryFetch = false;
                this.decision = data.decision;
                this.creditScoreResponse = data.acSummary;
                if (this.creditScoreResponse != null) {
                    this.toastr.success("Credit history fetch successfully.");
                    this.submit(this.y)
                    this.showCreditScore = true
                    this.noResult = false
                } else {
                    this.toastr.info("No Credit History found.");
                    this.submit(this.y)
                    this.noResult = true
                }
            }, error => {
                this.creditHistoryFetch = false;
                this.toastr.error("No Credit History found.");
                this.submit(this.y);
            });
    }

    submit(y) {
        // delete this.model["dateOfBirth"];
        var patternTrn = /(^0$)|(^[1-9]\d{0,8}$)/;
        var patternName = /^[a-zA-Z]*$/;
        var patternMobile = /(^0$)|(^[1-9]\d{0,9}$)/;
        var patternInvest = /^[1-9]\d*$/;

        if (this.model.customerType == '' || this.model.customerType == null || this.model.customerType == "Please Select") {
            this.toastr.warning("Customer Type is Required");
            return
        }


        if (this.model.tRN == null || this.model.tRN == "") {
            this.toastr.warning("TRN is Required");
            return
        }

        if (this.model.tRN.length > 9) {
            this.toastr.warning("TRN length cannot be more than 9");
            return
        }

        else if (this.model.tRN != null && this.model.tRN != "") {
            if (!this.model.tRN.match(patternTrn)) {
                this.toastr.warning("Invalid TRN");
                return
            }
        }

        if (this.model.firstName == null || this.model.firstName == "") {
            this.toastr.warning("First Name is Required");
            return
        }
        if (this.model.firstName != null && this.model.firstName != "") {
            if (!this.model.firstName.match(patternName)) {
                this.toastr.warning("Invalid First Name");
                return
            }
            else if (this.model.firstName.length > 30) {
                this.toastr.warning("First Name length cannot be more than 30");
                return
            }
        }


        if (this.model.lastName == null || this.model.lastName == "") {
            this.toastr.warning("Last Name is Required");
            return

        }
        if (this.model.lastName != null && this.model.lastName != "") {
            if (!this.model.lastName.match(patternName)) {
                this.toastr.warning("Invalid Last Name");
                return
            }
            else if (this.model.lastName.length > 30) {
                this.toastr.warning("Last Name length cannot be more than 30");
                return
            }
        }
        if (this.model.dateOfBirth == '' || this.model.dateOfBirth == null) {
            this.toastr.warning("Date of Birth is Required");
            return
        }

        if (this.model.mobileNumber == '' || this.model.mobileNumber == '') {
            this.toastr.warning("Mobile Number is Required");
            return
        }

        if (this.model.mobileNumber.length > 10) {
            this.toastr.warning("Mobile Number length cannot be more than 10");
            return
        }

        else if (this.model.mobileNumber != null && this.model.mobileNumber != "") {
            if (!this.model.mobileNumber.match(patternMobile)) {
                this.toastr.warning("Invalid Mobile Number");
                return
            }
        }

        if ((this.model.loanAmount == null && this.productParent == "Business Loan") || (this.model.loanAmount == "" && this.productParent == "Business Loan")) {
            this.toastr.warning("Loan amount is Required");
            return
        }

        if ((this.model.loanAmount != null && this.productParent == "Business Loan") && (this.model.loanAmount != "" && this.productParent == "Business Loan")) {
            if (!this.model.loanAmount.match(patternInvest)) {
                this.toastr.warning("Invalid Loan amount");
                return
            }
            else if (this.model.loanAmount.length > 20) {
                this.toastr.warning("Loan amount length cannot be more than 20");
                return
            }
        }


        if ((this.model["loanTenure(InMonths)"] == null && this.productParent == "Business Loan") || (this.model["loanTenure(InMonths)"] == "" && this.productParent == "Business Loan")) {
            this.toastr.warning("Loan tenure is Required");
            return
        }

        if ((this.model["loanTenure(InMonths)"] != null && this.productParent == "Business Loan") && (this.model["loanTenure(InMonths)"] != "" && this.productParent == "Business Loan")) {
            if (!this.model["loanTenure(InMonths)"].match(patternInvest)) {
                this.toastr.warning("Invalid Loan tenure");
                return
            }
            else if (this.model["loanTenure(InMonths)"].length > 20) {
                this.toastr.warning("Loan tenure length cannot be more than 20");
                return
            }
        }

        if (this.productParent == "Consumer Loan") {
            this.model.email = this.model.emailAddress
        } else {
            this.model.email = this.model.email;
        }


        this.model.mobileno = this.model.mobileNumber
        this.submitedData = true;
        this.model.productName = this.productName
        this.model.subproductName = this.subproductName
        this.model.subproductId = this.tempsubProductId
        this.model.branchPreferenceId = "1"
        this.model.productId = this.productId
        var patternText = /^[a-zA-Z]*$/;
        var patternEmail = /^[a-z0-9!#$%&'*+\/=?^_`{|}~.-]+@[a-z0-9]([a-z0-9-]*[a-z0-9])?(\.[a-z0-9]([a-z0-9-]*[a-z0-9])?)*$/i;
        if (this.t.activeId == "Level 1") {
            let requiredError = false;
            let emailError = false;
            let mobileError = false;
            let dateOfBirthError = false;
            let idExpirationDate = false;
            let placeOfBirth = false;

            if (typeof (this.model.dateOfBirth) == 'object') {
                let year = this.model.dateOfBirth["year"].toString();
                let month = this.model.dateOfBirth["month"].toString().length == 1 ? '0' + this.model.dateOfBirth["month"].toString() : this.model.dateOfBirth["month"].toString();
                let day = this.model.dateOfBirth["day"].toString().length == 1 ? '0' + this.model.dateOfBirth["day"].toString() : this.model.dateOfBirth["day"].toString();
                let date = year + '-' + month + '-' + day;
                let birthDate = new Date(date + 'T10:20:30Z');

                var today = new Date();
                //var year = +this.model.dateofBirth.split('-')[0] - today.getFullYear();
                var age = today.getFullYear() - birthDate.getFullYear();
                var m = today.getMonth() - birthDate.getMonth();
                if (m < 0 || (m === 0 && today.getDate() < birthDate.getDate())) {
                    age--;
                }
                if (age < 18) {
                    dateOfBirthError = true;
                }
                if (age > 80) {
                    this.toastr.error("Please select date of birth less than 80 years");
                    this.submitedData = false;
                }
                if (typeof (this.model.dateOfBirth) == 'object') {
                    this.model.dateOfBirth = (this.model.dateOfBirth["year"] + '-' + this.model.dateOfBirth["month"] + '-' + + this.model.dateOfBirth["day"]).toString()
                }
            }
            if (typeof (this.model.iDExpirationDate) == 'object') {
                let year = this.model.iDExpirationDate["year"].toString();
                let month = this.model.iDExpirationDate["month"].toString().length == 1 ? '0' + this.model.iDExpirationDate["month"].toString() : this.model.iDExpirationDate["month"].toString();
                let day = this.model.iDExpirationDate["day"].toString().length == 1 ? '0' + this.model.iDExpirationDate["day"].toString() : this.model.iDExpirationDate["day"].toString();
                let date = year + '-' + month + '-' + day;
                let birthDate = new Date(date + 'T10:20:30Z');

                var now = new Date();
                now.setHours(0, 0, 0, 0);
                if (birthDate < now) {
                    idExpirationDate = true;
                    // selected date is in the past
                }
                if (typeof (this.model.iDExpirationDate) == 'object') {
                    this.model.iDExpirationDate = (this.model.iDExpirationDate["year"] + '-' + this.model.iDExpirationDate["month"] + '-' + + this.model.iDExpirationDate["day"]).toString()
                }
            }
            if (this.model.email != null && this.model.email != "") {
                if (!this.model.email.match(patternEmail)) {
                    emailError = true;
                }
            }
            else {
                emailError = false;
            }

            if (this.model.mobileno != null && this.model.mobileno != "") {
                if (!this.model.mobileno.match(patternMobile)) {
                    mobileError = true;
                }
            }
            else {
                mobileError = false;
            }
            /* for place of birth validation*/
            console.log(this.model.placeOfBirth);
            if ((this.model.placeOfBirth == null || this.model.placeOfBirth == '') && this.y == 1) {
                placeOfBirth = true;
            } else {
                placeOfBirth = false;
            }

            for (var i = 0; i < this.template[0]['sections'].length; i++) {
                for (var j = 0; j < this.template[0]['sections'][i]["fields"].length; j++) {
                    if (this.template[0]['sections'][i]["fields"][j]['templateOptions'] != undefined) {
                        if (this.template[0]['sections'][i]["fields"][j]['templateOptions']['required'] == true) {
                            //this.requiredFieldsKey.push(this.template[0]['sections'][i]["fields"][j]['key']);
                            var keyName = this.template[0]['sections'][i]["fields"][j]['key'];
                            if (this.model[keyName] == undefined || this.model[keyName] == "" || this.model[keyName] == "Please Select") {
                                requiredError = true;
                            }
                        }
                    }
                }
            }
            if (requiredError) {
                this.toastr.error("Please fill all the required fields in Level 1!");
                this.submitedData = false;
            }

            else if (dateOfBirthError) {
                this.toastr.error("Please select date of birth more than 18 years");
                this.submitedData = false;
            }
            else if (idExpirationDate) {
                this.toastr.error("Id Expiry date should be greater than today!");
                this.submitedData = false;
            }
            else if (emailError) {
                this.toastr.error("Invalid email address.");
                this.submitedData = false;
            }
            else if (mobileError) {
                this.toastr.error("Invalid mobile number.");
                this.submitedData = false;
            }


            else {
                this.proceedDisabled = true
                // Lead  id generation
                if (y == 0) {
                    var dataTab1 = {
                        "validationContext": "test",
                        "leadData": this.model,
                    };
                    this.leadService.saveLead(dataTab1).subscribe((d: any) => {
                        setTimeout(() => {
                            this.submitedData = false;
                            this.leadId = d.message;
                            this.model.leadId = this.leadId
                        }, 3000);
                    }, error => {
                        this.toastr.error("No hit");
                    });
                    this.proceedDis = true;
                    this.otpPop = true;
                    this.otp = null;

                }
                //Level1 Save
                if (y == 1) {

                    if (this.productParent == "Consumer Loan") {
                        this.a = this.ffv.level1ConsumerValidation(this.model);
                    } else {
                        this.a = this.ffv.level1BusinessValidation(this.model);
                    }

                    var dataTab = {
                        'id': this.leadId,
                        "validationContext": "test",
                        "leadData": this.model
                    };

                    if (this.a == 1) {
                        this.leadService.updateLead(dataTab).subscribe((d: any) => {
                            setTimeout(() => {
                                this.submitedData = false;
                                this.model.leadId = this.leadId
                                this.template[1].active = true;
                                this.template[0].active = true;
                            }, 3000);
                        }, error => {
                            this.toastr.error("No hit");
                        });

                        this.toastr.success("Level 1 details have been submitted successfully.");
                        this.workflowLevelUpdate("levelonesubmitted")
                    }


                }
            }
        }
        else if (this.t.activeId == "Level 2") {
            if (this.productParent == "Consumer Loan") {
                this.a = this.ffv.level2ConsumerValidation(this.model);
            }
            let requiredError = false;
            for (var i = 0; i < this.template[1]['fields'].length; i++) {
                if (this.template[1]['fields'][i]['templateOptions'] != undefined) {
                    if (this.template[1]["fields"][i]['templateOptions']['required'] == true) {
                        var keyName = this.template[1]["fields"][i]['key'];
                        if (this.model[keyName] == undefined || this.model[keyName] == "") {
                            requiredError = true;
                        }
                    }
                }
            }
            if (requiredError) {
                this.toastr.error("Please fill  all the required fields in Level 2!");
                this.submitedData = false;
            }
            else {

                var dataTab2 = {
                    'id': this.leadId,
                    "validationContext": "test",
                    "leadData": this.model
                }
                this.model.leadId = this.leadId
                // level 2 save
                if (this.productParent == "Consumer Loan") {
                    this.model.email = this.model.emailAddress
                } else {
                    this.model.email = this.model.email;
                }

                this.model.mobileno = this.mobile
                if (this.a == 1) {
                    this.leadService.updateLead(dataTab2).subscribe((d: any) => {
                            this.submitedData = false;
                            this.template[2].active = true;
                            this.toastr.success("Level 2 details have been submitted successfully.");
                            this.workflowLevelUpdate("leveltwosubmitted")
                        }, error => {
                            this.toastr.error("Something went wrong.");
                        });
                }
            }
        }
        else if (this.t.activeId == "Level 3") {
            if (this.productParent == "Consumer Loan") {
                this.a = this.ffv.level3ConsumerValidation(this.model);
            }
            let requiredError = false;
            for (var i = 0; i < this.template[2]['fields'].length; i++) {
                if (this.template[2]['fields'][i]['templateOptions'] != undefined) {
                    if (this.template[2]["fields"][i]['templateOptions']['required'] == true) {
                        var keyName = this.template[2]["fields"][i]['key'];
                        if (this.model[keyName] == undefined || this.model[keyName] == "") {
                            requiredError = true;
                        }
                    }
                }
            }
            if (requiredError) {
                this.toastr.error("Please fill  all the required fields in Level 3!");
                this.submitedData = false;
            }
            else {
                var dataTab3 = {
                    'id': this.leadId,
                    "validationContext": "test",
                    "leadData": this.model
                };
                this.model.leadId = this.leadId
                if (this.productParent == "Consumer Loan") {
                    this.model.email = this.model.emailAddress
                } else {
                    this.model.email = this.model.email;
                }
                this.model.mobileno = this.mobile
                // level 3 submit
                if (this.a == 1) {
                    this.leadService
                        .updateLead(dataTab3)
                        .subscribe((d: any) => {
                            this.submitedData = false;
                            this.docActive = true;
                            this.toastr.success("Level 3 details have been submitted successfully.");
                            this.workflowLevelUpdate("levelthreesubmitted")
                        }, error => {
                            this.toastr.error("Error in adding lead");
                        });
                }

            }
        }
        else if (this.t.activeId == "Upload Media") {
            console.log(this.documentArray["fields"]);
            for (let i = 0; i < this.documentArray["fields"].length; i++) {
                if (this.documentArray["fields"][i]["templateOptions"]["required"]) {
                    console.log(this.documentArray["fields"][i]["templateOptions"]["required"]);
                    this.uploadDocCount = i + 1;
                }
            }
            if (this.leadId != undefined) {
                var dataTab4 = {
                    "leadId": this.leadId,
                    "profileIdentifications": this.profileIdentifications,
                    "documentStatus": "completed"
                }

                if (this.productParent == "Consumer Loan") {
                    if (this.trnDocumentName == "" || this.trnDocumentName == null) {
                        this.checkMediaValidation = 0;
                    } else {
                        this.checkMediaValidation = 1;
                    }
                    if (this.licenceDocumentName == "" || this.licenceDocumentName == null) {
                        this.checkMediaValidation = 0;
                    } else {
                        this.checkMediaValidation = 1;
                    }
                    if (this.passportPhotograhDocumentName == "" || this.passportPhotograhDocumentName == null) {
                        this.checkMediaValidation = 0;
                    } else {
                        this.checkMediaValidation = 1;
                    }
                    if (this.jobLetter == "" || this.jobLetter == null) {
                        this.checkMediaValidation = 0;
                    } else {
                        this.checkMediaValidation = 1;
                    }
                    if (this.payInSlip3Months == "" || this.payInSlip3Months == null) {
                        this.checkMediaValidation = 0;
                    } else {
                        this.checkMediaValidation = 1;
                    }
                    if (this.signedConsentForm == "" || this.signedConsentForm == null) {
                        this.checkMediaValidation = 0;
                    } else {
                        this.checkMediaValidation = 1;
                    }
                    if (this.creditBureuReport == "" || this.creditBureuReport == null) {
                        this.checkMediaValidation = 0;
                    } else {
                        this.checkMediaValidation = 1;
                    }
                    if (this.clientSignature == "" || this.clientSignature == null) {
                        this.checkMediaValidation = 0;
                    } else {
                        this.checkMediaValidation = 1;
                    }
                } else {
                    if (this.licenceDocumentName == "" || this.licenceDocumentName == null) {
                        this.checkMediaValidationBusiness = 0;
                    } else {
                        this.checkMediaValidationBusiness = 1;
                    }
                    if (this.passportPhotograhDocumentName == "" || this.passportPhotograhDocumentName == null) {
                        this.checkMediaValidationBusiness = 0;
                    } else {
                        this.checkMediaValidationBusiness = 1;
                    }
                    if (this.taxRegistrationNumberName == "" || this.taxRegistrationNumberName == null) {
                        this.checkMediaValidationBusiness = 0;
                    } else {
                        this.checkMediaValidationBusiness = 1;
                    }
                    if (this.referenceLetterName == "" || this.referenceLetterName == null) {
                        this.checkMediaValidationBusiness = 0;
                    } else {
                        this.checkMediaValidationBusiness = 1;
                    }
                    if (this.directionsToBusinessName == "" || this.directionsToBusinessName == null) {
                        this.checkMediaValidationBusiness = 0;
                    } else {
                        this.checkMediaValidationBusiness = 1;
                    }
                    if (this.photographsOfBusinessPlaceName == "" || this.photographsOfBusinessPlaceName == null) {
                        this.checkMediaValidationBusiness = 0;
                    } else {
                        this.checkMediaValidationBusiness = 1;
                    }
                }

                if (this.checkMediaValidation == 1 && this.productParent == "Consumer Loan") {
                    //upload document submit
                    this.leadService
                        .updateLeadDocuments(dataTab4)
                        .subscribe((d: any) => {
                            this.toastr.success("Upload document have been submitted successfully.");
                            this.submitedData = false;
                            //this.workflowSetup()
                        }, error => {
                            this.toastr.error("Something went wrong.");
                        });
                }
                else if (this.checkMediaValidationBusiness == 1 && this.productParent == "Business Loan") {
                    this.leadService
                        .updateLeadDocuments(dataTab4)
                        .subscribe((d: any) => {
                            this.toastr.success("Upload document have been submitted successfully.");
                            this.submitedData = false;
                           // this.workflowSetup()
                        }, error => {
                            this.toastr.error("Error in adding lead.");
                        });
                }
                else {
                    this.submitedData = false;
                    this.toastr.error("Please upload all mandatory documents!")
                }
            } else {
                this.submitedData = false;
                this.toastr.error("You need to fill previous levels data before add the documents!")
            }
        }
    }

    previewFile(key) {
        let documentExist = false;
        if (this.profileIdentifications.length > 0) {
            for (var i = 0; i < this.profileIdentifications.length; i++) {
                if (this.profileIdentifications[i]["identificationDocTypeId"] == key) {
                    documentExist = true;
                    var imagetype = this.profileIdentifications[i]['fileName'].substr(this.profileIdentifications[i]['fileName'].length - 3);
                    this.leadService
                        .filePreview(this.profileIdentifications[i]['fileName'])
                        .subscribe(res => {
                            if (imagetype == "pdf") {
                                var mediaType = 'application/pdf';
                            } else if (imagetype == "txt") {
                                var mediaType = 'text/plain';
                            } else if (imagetype == "xls") {
                                var mediaType = 'application/excel';

                            } else if (imagetype == "doc") {
                                var mediaType = 'application/msword';
                            } else {
                                var mediaType = 'image/jpeg';
                            }
                            var file = new Blob([res.blob()], { type: mediaType });
                            if (window.navigator && window.navigator.msSaveOrOpenBlob) {
                                window.navigator.msSaveOrOpenBlob(file);
                            } else {
                                let url = window.URL.createObjectURL(file);
                                window.open(url);
                            }
                        });
                }
            }
        }
    }
    cancel() {
        this.isPopedUp = false;
    }
    cancleClick() {
        this.isPopedUp = true;
    }
    search(nameKey, myArray) {
        for (var i = 0; i < myArray.length; i++) {
            if (myArray[i].name === nameKey) {
                return myArray[i];
            }
        }
    }
    postLeadinfo() {
        this.leadService
            .postUpdateLeadId(this.leadId)
            .subscribe((d: any) => {

            }, error => {
                this.toastr.error("Error in adding lead.");
            });
    }
    addFileToDocument(docKey, event) {
        const fileList: FileList = event.target.files;
        if (fileList.length > 0) {
            const file: File = fileList[0];
            const fd: FormData = new FormData();
            fd.append('file', file);
            this.leadService
                .uploadFile(fd)
                .subscribe(data => {
                    for (var i = 0; i < this.profileIdentifications.length; i++) {
                        if (this.profileIdentifications[i]['identificationTypeId'] == docKey) {
                            this.profileIdentifications.splice(i, 1);
                        }
                    }
                    let obj = {
                        "id": "",
                        "path": data["path"],
                        "fileName": data["fileName"],
                        "identificationTypeId": docKey,
                        "identificationDocTypeId": docKey,
                        "identificationDocId": "",
                        "deferredTillDate": "",
                        "isDeferred": "",
                        "IsWavedOff": "",
                        "isDelete": "false",
                        "tflexId": this.leadId
                    };
                    this.profileIdentifications.push(obj);
                });
            console.log(this.profileIdentifications);
            if (docKey == "tRN") {
                this.trnDocumentName = file["name"];
                console.log(this.trnDocumentName);
            }
            if (docKey == "driverLicense") {
                this.licenceDocumentName = file["name"];
            }
            if (docKey == "passportSizePhotograph") {
                this.passportPhotograhDocumentName = file["name"];
            }
            if (docKey == "electricityBill") {
                this.electricityBillDocumentName = file["name"];
            }
            if (docKey == "phoneBill") {
                this.phoneBill = file["name"];
            }
            if (docKey == "bankStatement") {
                this.bankStatement = file["name"];
            }
            if (docKey == "jobLetter") {
                this.jobLetter = file["name"];
            }
            if (docKey == "paySlips(3Months)") {
                this.payInSlip3Months = file["name"];
            }
            if (docKey == "guarantorLetter") {
                this.guarantorLetter = file["name"];
            }
            if (docKey == "assetPurchaseReceipts") {
                this.assetPurchaseReciept = file["name"];
            }
            if (docKey == "letterOfHypothecation") {
                this.letterOfHypothecation = file["name"];
            }
            if (docKey == "motorVehicleTitle") {
                this.motorVehicleTitle = file["name"];
            }
            if (docKey == "stockCertificate") {
                this.stockCertificate = file["name"];
            }
            if (docKey == "signedConsentForm") {
                this.signedConsentForm = file["name"];
            }
            if (docKey == "creditBureauReport") {
                this.creditBureuReport = file["name"];
            }
            if (docKey == "clientSignature") {
                this.clientSignature = file["name"];
            }
            if (docKey == "taxRegistrationNumber") {
                this.taxRegistrationNumberName = file["name"];
            }
            if (docKey == "referenceLetter") {
                this.referenceLetterName = file["name"];
            }
            if (docKey == "companyRegistrationCertificate") {
                this.companyRegistrationCertificateName = file["name"];
            }
            if (docKey == "businessLicence") {
                this.businessLicenceName = file["name"];
            }
            if (docKey == "directionsToBusiness") {
                this.directionsToBusinessName = file["name"];
            }
            if (docKey == "photographsOfBusinessPlace") {
                this.photographsOfBusinessPlaceName = file["name"];
            }
        }
    }
    tabClick(activeId) {

        if (activeId == "Level 1") {
            this.tabButtonTitle = "Proceed";
            this.activeTabId = activeId;
            this.showCreditInfoButton = true
        } else {
            this.leveloneSubmitted = true
            this.proceedDisabled = false
            this.tabButtonTitle = "Save";
            this.activeTabId = activeId;
            this.showCreditInfoButton = false
        }
    }
    workflowLevelUpdate(data) {
        let leadinfo = {
            ApplicationStatus: data,
            AssignTo: "",
            NextApplicationStatus: "",
            NextActionDate: new Date(),
            Remarks: "",
            LeadId: this.leadId
        }
        this.leadService.workflowLeadLevelUpdate(leadinfo).subscribe((d: any) => {
            }, error => {
                this.toastr.error("Error in adding lead.");
            });
    }

    filterData() {
        this.filter = !this.filter;
    }
    clickChangeLoantype() {
        this.changeLoanUp = true;
    };
    cancelLoanType() {
        this.changeLoanUp = false;
    }
    goToLead(cancelReason) {
        this.changeLoanUp = false;
        this.model.loanId = cancelReason;
        this.templateSearch = false;
        this.template = [];
        this.model = {};
        this.documentArrayIsEmpty = true;
    }

    doCalculations(data, form) {
        //dedupe check
		//console.log(data);
		//console.log(form);
		//alert(form._value.customerType);
        if (data.customerType == "New" || data.customerType == "Please Select") {
            this.x = 0;
            if (this.customerTypeFlag == 0) {
                this.form.controls['firstName'].setValue('');
                this.form.controls['lastName'].setValue('');
                this.form.controls['mobileNumber'].setValue('');
                this.form.controls['tRN'].setValue('');
                this.form.controls['dateOfBirth'].setValue('');
                this.customerTypeFlag = 1;
            }
        }
        if (data.customerType == "Existing") {
            if (this.x == 0) {
                this.x++;
                this.existingLead1 = true;
                this.leadCheck = null;
            }

        }
        //Toatal Income calculations BL
        if (form.controls.hasOwnProperty('netSales')) {
            var netSales = Number(form.controls['netSales'].value || 0);
            var otherIncome = Number(form.controls['otherIncome'].value || 0);
            var totalIncome = netSales + otherIncome;
            form.controls['totalIncome'].setValue(totalIncome);
        }
        //Toatal Expences calculations BL
        if (form.controls.hasOwnProperty('employee/OwnerSalary')) {
            var employeeOwnerSalary = Number(form.controls['employee/OwnerSalary'].value || 0);
            var rentMortgage = Number(form.controls['rent/Mortgage'].value || 0);
            var light = Number(form.controls['light'].value || 0);
            var water = Number(form.controls['water'].value || 0);
            var food = Number(form.controls['food'].value || 0);
            var telephoneCredit = Number(form.controls['telephone/Credit'].value || 0);
            var transportation = Number(form.controls['transportation'].value || 0);
            var hirePurchase = Number(form.controls['hirePurchase'].value || 0);
            var insurancePartner = Number(form.controls['insurance/Partner'].value || 0);
            var loanPayment = Number(form.controls['loanPayment'].value || 0);
            var creditCardPayment = Number(form.controls['creditCardPayment'].value || 0);
            var educationSchooling = Number(form.controls['education&Schooling'].value || 0);
            var otherMiscellaneous = Number(form.controls['other/Miscellaneous'].value || 0);
            var totalExpences = employeeOwnerSalary + rentMortgage + light + water + food + telephoneCredit + transportation + hirePurchase + insurancePartner + loanPayment + creditCardPayment + educationSchooling + otherMiscellaneous;
            form.controls['totalExpenses'].setValue(totalExpences);
            var dISPOSABLEINCOME = totalIncome - totalExpences;
            form.controls['dISPOSABLEINCOME'].setValue(dISPOSABLEINCOME);
        }
        //Assets calculations BL
        if (form.controls.hasOwnProperty('realEstate-Fixed')) {
            var realEstateFixed = Number(form.controls['realEstate-Fixed'].value || 0);
            var motorVehicleFixed = Number(form.controls['motorVehicle-Fixed'].value || 0);
            var furnitureFixed = Number(form.controls['furniture'].value || 0);
            var householdAppliancesFixed = Number(form.controls['householdAppliances'].value || 0);
            var businessEquipmentFixed = Number(form.controls['businessEquipment'].value || 0);
            var otherFixed = Number(form.controls['other-Fixed'].value || 0);
            var cashInHandCurrent = Number(form.controls['cashInHand'].value || 0);
            var cashAtBankCurrent = Number(form.controls['cashAtBank'].value || 0);
            var stockCurrent = Number(form.controls['stock'].value || 0);
            var otherCurrent = Number(form.controls['other-Current'].value || 0);
            var totalAssets = realEstateFixed + motorVehicleFixed + furnitureFixed + householdAppliancesFixed + businessEquipmentFixed + otherFixed + cashInHandCurrent + cashAtBankCurrent + stockCurrent + otherCurrent;
            console.log('totalAssets : ' + totalAssets);
            form.controls['totalAssets'].setValue(totalAssets);
            var realEstateLiabilities = Number(form.controls['realEstate-Liabilities'].value || 0);
            var motorVehicleLiabilities = Number(form.controls['motorVehicle-Liabilities'].value || 0);
            var furnitureAndAppliancesLiabilities = Number(form.controls['furnitureAndAppliances'].value || 0);
            var creditCardBalanceLiabilities = Number(form.controls['creditCardBalance'].value || 0);
            var loanBalanceLiabilities = Number(form.controls['loanBalance'].value || 0);
            var totalLiabilities = realEstateLiabilities + motorVehicleLiabilities + furnitureAndAppliancesLiabilities + creditCardBalanceLiabilities + loanBalanceLiabilities;
            console.log('totalLiabilities : ' + totalLiabilities);
            form.controls['totalLiabilities'].setValue(totalLiabilities);
            var nETWORTH = totalAssets - totalLiabilities;
            console.log('nETWORTH : ' + nETWORTH);
            form.controls['nETWORTH'].setValue(nETWORTH);
        }
    }

    cancelexistingLead() {
        this.existingLead1 = false;
    }

    goToexistingLead(leadCheck) {
        this.existingLead1 = false;
        var data = {
            "SearchKeyword": leadCheck,
            "CustomerType": "Existing"
        }
        this.existingLeadsearchPop = true;

        this.leadService.SearchExixtingLead(data).subscribe((result) => {
            this.searchDataPaging = result;
        }, error => {
            this.toastr.error("No lead found.");
        });
    }

    cancelexistingLeadsearchPop() {
        this.existingLeadsearchPop = false;
    }

    handleChange(firstName, lastName, mobile, trn, dob) {
		console.log(firstName);
		console.log(lastName);
		console.log(mobile);
		console.log(trn);
		console.log(dob);
		console.log('here');
		console.log(this.form);
        this.form.controls['firstName'].setValue(firstName);
        this.form.controls['lastName'].setValue(lastName);
        if (this.productParent == "Business Loan") {
            this.form.controls['mobileNumber'].setValue(mobile);
        } else {

            this.form.controls['mobileNumber'].setValue(mobile);
        }
        this.form.controls['tRN'].setValue(trn);
        this.existingLeadsearchPop = false;
        var splitEndDate = dob.split('-');
        let a =
            {
                "year": +splitEndDate[2],
                "month": +splitEndDate[0].replace(/(^0)/g, ""),
                "day": +splitEndDate[1].replace(/(^0)/g, ""),
            };
        console.log(a);
        this.form.controls['dateOfBirth'].setValue(a);
        this.customerTypeFlag = 0;
    }

    cancelLevel1() {
        this.workflowLevelUpdate("salesrejected");
        window.location.reload();
    }

    cancelUpload() {
        window.location.reload();
    }

    submitLevelOne() {
        this.y = 1;
        this.submit(this.y);

    }
    submitOTP(otp) {
        let data = {
            "LeadId": this.leadId,
            "OTP": otp
        }
        this.leadService.submitOTP(data).subscribe((result: any) => {
            let responsecheck = result.response;
            if (responsecheck == "OTP Verified") {
                this.toastr.success("Lead has been submitted successfully.");
                this.otpPop = false;
                this.leadService.GetLeadById(this.leadId).subscribe((data: any) => {
                        this.toastr.success("Application ID No: " + '"' + data.ApplicationNumber + '".');
                        this.mobile = data.mobileno;
                        this.proceedDis = true;
                        this.generateDis = true;
                        this.submitLevel1 = false;
                    });
            }
        },
            error => {
                this.toastr.error("Invalid OTP");
            });
    }

    cancelOTP() {
        this.otpPop = false
        this.proceedDis = false;
    }

}
